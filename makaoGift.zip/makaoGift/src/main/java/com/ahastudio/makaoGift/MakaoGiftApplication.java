package com.ahastudio.makaoGift;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MakaoGiftApplication {

	public static void main(String[] args) {
		SpringApplication.run(MakaoGiftApplication.class, args);
	}

}
